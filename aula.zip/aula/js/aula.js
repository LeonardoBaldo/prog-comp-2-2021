let CPU = new Object()
CPU.marca = "Intel"
CPU.modelo = "i9"
CPU.ano = 2020
CPU.gen = "10th"

console.log(CPU)

let GPU = new Object()
GPU.marca = "NVIDIA"
GPU.modelo = "GeForce RTX"
GPU.chip = 3090
GPU.memoria = "24G"

console.log(GPU)